// Membuat variable untuk menampung nilai yang dikirim dari clint atau request dari client
const books = [];

module.exports = books;
